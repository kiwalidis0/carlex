import React from "react";
import BasicForms from "./BasicForms";
import {Route, Routes, Link} from 'react-router-dom';
import ControlledInput from "./ControlledInput";
import UncontrolledInput from "./UncontrolledInput";

const MyMainForms = () => {
    return(
        <div>
            <h1>React Forms App</h1>
            <nav>
                <ul>
                    <li><Link to="basic-form">Basic Form</Link></li>
                    <li><Link to="controlled-input">Controlled Input</Link></li>
                    <li><Link to="uncontrolled-input">Uncontrolled Input</Link></li>
                </ul>
            </nav>

            <Routes>
                <Route path="basic-form" element={<BasicForms/>}/>
                <Route path="controlled-input" element={<ControlledInput/>}/>
                <Route path="uncontrolled-input" element={<UncontrolledInput/>}/>
            </Routes>
            
        </div>

    );
};

export default MyMainForms;